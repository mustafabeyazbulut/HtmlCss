$(document).ready(function(){

  $("#today").click(function () {
      $("ul").removeClass().addClass("l1");
      $("#content").removeClass().addClass("m1");
  });

  $("#planning").click(function () {
      $("ul").removeClass().addClass("l2");
      $("#content").removeClass().addClass("m2");
  });

  $("#contacts").click(function () {
      $("ul").removeClass().addClass("l3");
      $("#content").removeClass().addClass("m3");
  });

  $("#events").click(function () {
      $("ul").removeClass().addClass("l4");
      $("#content").removeClass().addClass("m4");
  });

  $("li").click(function () {
      $(this).addClass("active").siblings().removeClass('active')
  });

  //-------------------------------------------------------------//

  $(".cardSpecific").click(function () {
      $(this).toggleClass("rotate");
      $(this).children('.back').toggleClass("showBack");
  });

})